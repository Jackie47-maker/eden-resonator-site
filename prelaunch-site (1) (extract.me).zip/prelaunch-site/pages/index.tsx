import Head from 'next/head';
import Link from 'next/link';
import Countdown from '../components/Countdown';

export default function Home() {
  return (
    <>
      <Head>
        <title>Eden Pre-Launch Party</title>
      </Head>
      <main className="container mx-auto p-8">
        <h1 className="text-4xl font-bold">Global Pre-Launch Party</h1>
        <p className="mt-4">Join us on August 22, 2025. Countdown below:</p>
        <Countdown targetDate="2025-08-22T00:00:00Z" />
        <div className="mt-6">
          <Link href="/donate">Donate</Link>
        </div>
      </main>
    </>
  );
}
