export default function MediaGallery() {
  return (
    <main className="container mx-auto p-8">
      <h1 className="text-3xl font-bold">Media Gallery</h1>
      <p>Media content goes here.</p>
    </main>
  );
}
