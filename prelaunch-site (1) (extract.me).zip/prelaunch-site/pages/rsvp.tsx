import { useState } from 'react';

export default function RSVP() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch('/api/rsvp', { method: 'POST', body: JSON.stringify({ email }) });
    setSubmitted(true);
  };

  return (
    <main className="container mx-auto p-8">
      <h1 className="text-3xl font-bold">RSVP for Pre-Launch Party</h1>
      {!submitted ? (
        <form onSubmit={handleSubmit} className="mt-4">
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="Your email"
            required
            className="border p-2 w-full"
          />
          <button type="submit" className="mt-2 bg-blue-600 text-white p-2 rounded">Submit</button>
        </form>
      ) : (
        <p>Thanks for RSVPing! Check your email for details.</p>
      )}
    </main>
  );
}
