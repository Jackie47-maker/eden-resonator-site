export default function Donate() {
  return (
    <main className="container mx-auto p-8">
      <h1 className="text-3xl font-bold">Support Eden Resonator</h1>
      <a
        href="https://cash.app/$edenrevealed"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-6 inline-block bg-green-500 text-white py-3 px-6 rounded-lg"
      >
        Donate via Cash App
      </a>
    </main>
  )
}
